# Procurement-decisions corpus — 2026-05-18 full run

> 283 cryptographically-verifiable MeshQu receipts on real UK public-procurement records from the Contracts Finder OCDS feed.
> Every bundle in this archive is independently verifiable at <https://verify.meshqu.com> or via the `@meshqu/verifier` CLI.
> See the full notebook entry at `procurement-decisions/results/notebook/2026-05-18-full-run.md` in the parent repository.

## What's in this archive

```
bundles/
├── <decision_id>.bundle.json    × 283
└── (no other files)
README.md                        ← this file
```

Each `<decision_id>.bundle.json` is a complete v2 receipt bundle (`application/x.meshqu.bundle+json`) carrying:

- `files.receipt.json` — the signed receipt (Ed25519 signature, integrity hash, transparency anchor)
- `files.policy_snapshot.json` — the policy snapshot the receipt evaluated against
- `files.trusted_keys.json` — the public key for the signing kid
- `files.transparency_proof.json` — the Rekor inclusion proof
- `files.bundle_manifest.json` — the bundle's own manifest hash
- `manifest` — top-level integrity envelope

## Run metadata

| | |
|---|---|
| Run ID | `dry-run-7ddf7274-695f-4b1b-a335-b8ed006cc26d` |
| Date | 2026-05-18 (UTC 10:38:12 → 11:11:42) |
| OCDS window | 2024-12-01 → 2026-04-30 (straddles UK PA23 commencement, 2025-02-24) |
| Records attempted | 300 |
| Receipts produced | 300 (effective n=283 unique after OCDS feed deduplication) |
| Errors / orphans / retries | 0 / 0 / 0 |
| `policy_snapshot_id` (all bundles) | `cbf12348-6248-48f7-a06f-4e0304cc237e` |
| `policy_snapshot_digest` (all bundles) | `5d7d800186d4eda4a05f926bcaa34b23d56b31d923016cc6467952ee8fc0cc9d` |
| `signature_kid` (all bundles) | `meshqu-experiment-procurement-2026-05` |
| Substrate adapter version | `0.1.0` |
| Agent | `gpt-5.4-2026-03-05` at temperature 0 |

## How to verify

### Option A — verify.meshqu.com (in-browser, recommended for spot checks)

1. Open <https://verify.meshqu.com>
2. Drop any `bundles/<decision_id>.bundle.json` into the verifier
3. Expected: **"Bundle Verified with Caveats — Schema v2"** with all cryptographic checks (integrity / signature / transparency / canonicalization) passing
4. Two known non-blocking warnings: `snapshot_replay.skipped_in_browser` (browser can't run the rule evaluator; server-side verifier covers this) and `approval_lineage.no_resolvable_versions` (cosmetic; tamper-pinning intact via `policy_snapshot_digest`)

### Option B — @meshqu/verifier CLI (for bulk verification)

```bash
# Iterate over every bundle in the archive
for f in bundles/*.bundle.json; do
  meshqu-verifier verify "$f" || echo "FAILED: $f"
done
```

### Option C — Independent Rekor lookup (for transparency anchor verification)

Every receipt carries a `transparency_anchor.rekor_public_url` pointing at a sigstore.dev entry. The receipt's integrity hash is bound to that entry's DSSE envelope. Independent verification path that doesn't trust the MeshQu API at all.

## Provenance

This corpus is the empirical artefact of the procurement-decisions experiment. Authoritative sources:

- Pre-registered predictions: `procurement-decisions/planning/predictions.md` (tag `v0.1-predictions-locked`)
- Decision log: `procurement-decisions/planning/decision_log.md`
- Run notebook: `procurement-decisions/results/notebook/2026-05-18-full-run.md`
- Live-run observations: `procurement-decisions/results/notebook/2026-05-18-full-run-live-notes.md`
- Methodology findings: `procurement-decisions/results/notebook/findings/{001,002,003,004}-*.md`
