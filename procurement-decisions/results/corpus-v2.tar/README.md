# procurement-decisions corpus-v2 — repaired copy of `corpus.tar` (MRP-2026-02)

> The same 283 cryptographically-verifiable MeshQu receipts as `corpus.tar`,
> re-exported on 2026-09-23 after the bundle-export fix in
> TradeQu/tradequ#1156. Receipts, policy snapshots, transparency proofs and
> trusted keys are byte-identical to the original. The one addition is
> `policy_approval_receipts.json`, the signed approval record for the policy
> version every receipt evaluated against, which the original exporter could
> not include.
>
> See [`data/KNOWN_ISSUES.md`](../../data/KNOWN_ISSUES.md) §11 for the full
> account of what the original archive's `approval_lineage` failure meant and
> what this archive does and does not resolve.

## What this archive is

This is a *repair*, not a replacement. `corpus.tar` in this same directory is
untouched and remains the archive that published results and `DATA_MANIFEST.json`
digests cite. `corpus-v2.tar` carries the identical 283 decisions, the identical
signed receipts, policy snapshots, transparency proofs and trusted keys —
verified byte-for-byte identical to `corpus.tar` — plus the one file the
original exporter could not emit.

## What's in this archive

```
bundles/
├── <decision_id>.bundle.json    × 283
└── (no other files)
README.md                        ← this file
```

Each `<decision_id>.bundle.json` is a complete v2 receipt bundle (`application/x.meshqu.bundle+json`) carrying:

- `files.receipt.json` — the signed receipt (Ed25519 signature, integrity hash, transparency anchor) — byte-identical to `corpus.tar`
- `files.policy_snapshot.json` — the policy snapshot the receipt evaluated against — byte-identical to `corpus.tar`
- `files.trusted_keys.json` — the public key for the signing kid — byte-identical to `corpus.tar`
- `files.transparency_proof.json` — the Rekor inclusion proof — byte-identical to `corpus.tar`
- `files.policy_approval_receipts.json` — **new**: the signed approval record for the policy version this receipt evaluated against (see below)
- `files.bundle_manifest.json` — the bundle's own manifest hash; differs from `corpus.tar` only in `exported_at`, the new file's entry, and the resulting `manifest_digest`
- `manifest` — top-level integrity envelope

## Run metadata

Carried forward verbatim from `corpus.tar`'s README — nothing about the
underlying run changed:

| | |
|---|---|
| Run ID | `dry-run-7ddf7274-695f-4b1b-a335-b8ed006cc26d` |
| Date | 2026-05-18 (UTC 10:38:12 → 11:11:42) |
| OCDS window | 2024-12-01 → 2026-04-30 (straddles UK PA23 commencement, 2025-02-24) |
| Records attempted | 300 |
| Receipts produced | 300 (effective n=283 unique after OCDS feed deduplication) |
| Errors / orphans / retries | 0 / 0 / 0 |
| `policy_snapshot_id` (all bundles) | `cbf12348-6248-48f7-a06f-4e0304cc237e` |
| `policy_snapshot_digest` (all bundles) | `5d7d800186d4eda4a05f926bcaa34b23d56b31d923016cc6467952ee8fc0cc9d` |
| `signature_kid` (all bundles) | `meshqu-experiment-procurement-2026-05` |
| Substrate adapter version | `0.1.0` |
| Agent | `gpt-5.4-2026-03-05` at temperature 0 |

## How to verify — only as a reader can actually do it today

On <https://verify.meshqu.com>, a `corpus-v2.tar` bundle headlines
**"Bundle Not Fully Checked"** — no cryptographic check failed. Approval
lineage reads **"Not checked (nothing anchors which tenant these approvals
belong to)"**. That is because a bundle cannot vouch for its own tenant, and
the web verifier has no way to be told one to check against. This is a
different, narrower headline than the original `corpus.tar`, whose bundles
verify with an overall verdict of **"Bundle Failed Verification"** (see
[`data/KNOWN_ISSUES.md`](../../data/KNOWN_ISSUES.md) §11).

To anchor the tenant yourself, the expected tenant for every receipt in this
corpus is:

```
243f19a5-4d4f-4070-9ec1-8170e8260e26
```

A verifier given this expected tenant reports approval lineage **valid** (see
the verdict table in §11 of `KNOWN_ISSUES.md`). **A publicly available
verifier that accepts an expected tenant is not yet available** — do not run
`@meshqu/verifier` or any `meshqu-verify` / `meshqu-verifier` CLI against
these bundles expecting that check: the published `@meshqu/verifier` npm
package is a `0.0.0` placeholder with no binary, and no public CLI can
perform this check today.

### Independent Rekor lookup (for transparency anchor verification — unaffected by any of the above)

Every receipt carries a `transparency_anchor.rekor_public_url` pointing at a
sigstore.dev entry. The receipt's integrity hash is bound to that entry's
DSSE envelope. This path does not depend on MeshQu, on the bundle wrapper, or
on the tenant question above, and works identically for `corpus.tar` and
`corpus-v2.tar`.

## The approval record, stated honestly

`policy_approval_receipts.json` is a signed record, and its contents cannot
be edited — they are exactly what was ratified. Read plainly:

- `ratifier_id` and `ratifier_role` are both `staging-console-experiment-procurement` — a staging console credential, not a named individual.
- `approval_authority` is `unspecified`.
- `workflow_state` is `ratified`.
- The record was ratified on 2026-05-17, **before** this corpus froze on 2026-05-29.
- No individual approver is named anywhere in the record.

This is what the signed approval bytes say. It establishes that the policy
version was ratified, by whom the system was told to trust to ratify it in
this staging environment, and when — no more and no less.

## Provenance

Re-exported by [`scripts/build_corpus_v2_tar.py`](../../scripts/build_corpus_v2_tar.py)
from the public bundle endpoint:

    GET https://meshqu-api-staging.up.railway.app/v1/receipts/<decision_id>/bundle

following the exporter fix in TradeQu/tradequ#1156. Decision IDs were taken
from `corpus.tar` in this same directory, so the set is identical.

- Original archive: `procurement-decisions/results/corpus.tar`
- Known issue this repairs: [`data/KNOWN_ISSUES.md`](../../data/KNOWN_ISSUES.md) §11
